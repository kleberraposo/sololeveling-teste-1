
import React, { useState, useEffect, useCallback } from 'react';
import { 
  Menu, 
  PlusCircle, 
  UserCircle, 
  LayoutDashboard, 
  Trash2,
  X,
  Trophy,
  Zap,
  Clock,
  CheckCircle2,
  Dna,
  Book,
  Droplets,
  Apple,
  Moon,
  Layout,
  Coffee
} from 'lucide-react';
import { Player, Job, Title, Quest, Rank } from './types';
import { getSystemMessage } from './services/geminiService';
import { SystemModal } from './components/SystemModal';

const INITIAL_PLAYER: Player = {
  name: "Jogador",
  level: 1,
  rank: Rank.E,
  rankPoints: 0,
  job: Job.NONE,
  title: Title.NEWBIE,
  hp: { current: 100, max: 100 },
  mp: { current: 20, max: 20 },
  fatigue: 0,
  stats: { strength: 10, vitality: 10, agility: 10, intelligence: 10, perception: 10 },
  statPoints: 0,
  gold: 0,
  exp: 0,
  expToNext: 200 
};

const RANK_THRESHOLDS = [
  { rank: Rank.E, min: 0 },
  { rank: Rank.D, min: 100 },
  { rank: Rank.C, min: 300 },
  { rank: Rank.B, min: 600 },
  { rank: Rank.A, min: 1100 },
  { rank: Rank.S, min: 2100 },
];

const MISSION_CATEGORIES = [
  { name: "Flexões", type: "physical", icon: <Zap size={24} />, unit: "Reps" },
  { name: "Abdominais", type: "physical", icon: <Zap size={24} />, unit: "Reps" },
  { name: "Agachamentos", type: "physical", icon: <Zap size={24} />, unit: "Reps" },
  { name: "Hidratação Adequada", type: "hydration", icon: <Droplets size={24} />, unit: "Litros" },
  { name: "Sessão de Estudos", type: "study", icon: <Book size={24} />, unit: "Tempo" },
  { name: "Alimentação Saudável", type: "nutrition", icon: <Apple size={24} />, unit: "Check" },
  { name: "Protocolo de Sono", type: "sleep", icon: <Moon size={24} />, unit: "Horas" },
  { name: "Organização de Ambiente", type: "org", icon: <Layout size={24} />, unit: "Check" }
];

const App: React.FC = () => {
  const [player, setPlayer] = useState<Player>(INITIAL_PLAYER);
  const [quests, setQuests] = useState<Quest[]>([]);
  const [dailyQuest, setDailyQuest] = useState<any>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [activeView, setActiveView] = useState<'daily' | 'list' | 'create' | 'settings'>('daily');
  const [newName, setNewName] = useState("");
  const [newQuest, setNewQuest] = useState({ name: "", target: 1, description: "" });
  const [modal, setModal] = useState({ isOpen: false, title: '', message: '', type: 'info' as 'info' | 'alert' | 'reward' });

  const getRankColor = (rank: Rank) => {
    switch (rank) {
      case Rank.E: return 'text-slate-500';
      case Rank.D: return 'text-sky-400';
      case Rank.C: return 'text-emerald-400';
      case Rank.B: return 'text-indigo-400';
      case Rank.A: return 'text-fuchsia-500';
      case Rank.S: return 'text-amber-400';
      default: return 'text-white';
    }
  };

  const getRankGlowClass = (rank: Rank) => {
    if (rank === Rank.S) return 'drop-shadow-[0_0_8px_rgba(251,191,36,0.6)]';
    if (rank === Rank.A) return 'drop-shadow-[0_0_8px_rgba(217,70,239,0.4)]';
    return 'drop-shadow-[0_0_5px_rgba(56,189,248,0.3)]';
  };

  const handleCreateQuest = () => {
    if (!newQuest.name.trim()) return;
    const q: Quest = {
      id: Date.now().toString(),
      name: newQuest.name,
      target: newQuest.target,
      current: 0,
      description: newQuest.description
    };
    setQuests([...quests, q]);
    setNewQuest({ name: "", target: 1, description: "" });
    setActiveView('list');
    showModal("SISTEMA", "Diretriz manual registrada.", "info");
  };

  const generateDailyMission = useCallback((level: number) => {
    const template = MISSION_CATEGORIES[Math.floor(Math.random() * MISSION_CATEGORIES.length)];
    let target: any = 0;
    let displayTarget = "";
    let difficulty = "Fácil";

    if (level <= 25) difficulty = "Fácil";
    else if (level <= 60) difficulty = "Médio";
    else if (level <= 100) difficulty = "Difícil";
    else difficulty = "Mestre";

    switch (template.type) {
      case "physical":
        if (difficulty === "Fácil") target = Math.floor(Math.random() * 10) + 1; // 1-10
        else if (difficulty === "Médio") target = Math.floor(Math.random() * 16) + 5; // 5-20
        else if (difficulty === "Difícil") target = Math.floor(Math.random() * 16) + 10; // 10-25
        else target = Math.floor(Math.random() * 30) + 1; // 1-30
        displayTarget = `${target} Reps`;
        break;
      case "sleep":
        target = 8;
        displayTarget = "8 Horas";
        break;
      case "hydration":
        target = 2;
        displayTarget = "2 Litros";
        break;
      case "study":
        if (difficulty === "Fácil") { target = 30; displayTarget = "30 Minutos"; }
        else if (difficulty === "Médio") { target = 60; displayTarget = "1 Hora"; }
        else { target = 180; displayTarget = "3 Horas"; }
        break;
      case "nutrition":
      case "org":
        target = 1;
        displayTarget = "Concluir";
        break;
      default:
        target = 1;
        displayTarget = "Atividade";
    }

    return {
      id: 'daily-' + Date.now(),
      name: template.name,
      type: template.type,
      target,
      displayTarget,
      current: 0,
      difficulty,
      completed: false
    };
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem('sl_system_v10');
    if (saved) {
      const data = JSON.parse(saved);
      setPlayer(data.player);
      setQuests(data.quests);
      setDailyQuest(data.dailyQuest || generateDailyMission(data.player.level));
    } else {
      setDailyQuest(generateDailyMission(INITIAL_PLAYER.level));
    }
  }, [generateDailyMission]);

  useEffect(() => {
    if (dailyQuest) {
      localStorage.setItem('sl_system_v10', JSON.stringify({ player, quests, dailyQuest }));
    }
  }, [player, quests, dailyQuest]);

  const showModal = (title: string, message: string, type: 'info' | 'alert' | 'reward') => {
    setModal({ isOpen: true, title, message, type });
  };

  const getExpToNext = (level: number) => {
    if (level <= 25) return 200;
    if (level <= 60) return 400;
    if (level <= 100) return 800;
    return 1000;
  };

  const calculateDailyXP = (difficulty: string, level: number) => {
    if (level > 100) {
      return Math.random() < 0.4 ? 50 : Math.floor(Math.random() * 31) + 20; // 20-50 com 40% de ser 50
    }

    switch (difficulty) {
      case "Fácil": return Math.floor(Math.random() * 16) + 5; // 5-20
      case "Médio": return Math.floor(Math.random() * 26) + 5; // 5-30
      case "Difícil": 
      case "Mestre":
        return Math.floor(Math.random() * 31) + 20; // 20-50
      default: return 10;
    }
  };

  const addExpAndCheckLevel = (xp: number, gold: number) => {
    setPlayer(prev => {
      if (prev.level >= 999) return { ...prev, gold: prev.gold + gold };
      
      let newExp = prev.exp + xp;
      let newLevel = prev.level;
      let currentExpToNext = getExpToNext(newLevel);

      while (newExp >= currentExpToNext && newLevel < 999) {
        newLevel += 1;
        newExp = newExp - currentExpToNext;
        currentExpToNext = getExpToNext(newLevel);
        
        const lvl = newLevel;
        setTimeout(() => showModal("NÍVEL AUMENTOU", `O Sistema recalibrou sua força. Nível ${lvl} atingido.`, "reward"), 300);
      }

      return {
        ...prev,
        exp: newLevel >= 999 ? 0 : newExp,
        level: newLevel,
        expToNext: currentExpToNext,
        gold: prev.gold + gold
      };
    });
  };

  const updateQuest = (id: string, amount: number) => {
    setQuests(prev => prev.map(q => {
      if (q.id === id) {
        const newCurrent = Math.min(q.target, q.current + amount);
        if (newCurrent === q.target && q.current < q.target) {
          processRankRewards();
        }
        return { ...q, current: newCurrent };
      }
      return q;
    }));
  };

  const completeDailyQuest = () => {
    if (!dailyQuest || dailyQuest.completed) return;

    const xp = calculateDailyXP(dailyQuest.difficulty, player.level);
    addExpAndCheckLevel(xp, 30);
    
    setDailyQuest({ ...dailyQuest, current: dailyQuest.target, completed: true });
    
    showModal("MISSÃO CONCLUÍDA", `Protocolo de habitude finalizado. +${xp} XP | +30 Gold.`, "reward");
    
    setTimeout(() => {
      setDailyQuest(generateDailyMission(player.level));
    }, 2500);
  };

  const processRankRewards = () => {
    const xpGained = Math.floor(Math.random() * 10) + 5;
    let ptsGained = Math.floor(Math.random() * 20) + 10;

    addExpAndCheckLevel(xpGained, 40);

    setPlayer(prev => {
      let newRankPoints = prev.rankPoints + ptsGained;
      let newRank = prev.rank;
      const nextRankObj = RANK_THRESHOLDS.slice().reverse().find(t => newRankPoints >= t.min);
      if (nextRankObj && nextRankObj.rank !== prev.rank) {
        newRank = nextRankObj.rank;
        setTimeout(() => showModal("RANK AUMENTOU", `Nova autoridade de Rank: ${newRank}`, "reward"), 1000);
      }
      return { ...prev, rankPoints: newRankPoints, rank: newRank };
    });
  };

  const deleteQuest = (id: string) => {
    setQuests(quests.filter(q => q.id !== id));
  };

  const changeName = () => {
    if (newName.trim()) {
      setPlayer({ ...player, name: newName });
      setNewName("");
      setActiveView('daily');
      showModal("SISTEMA", "Codinome registrado.", "info");
    }
  };

  const getRankProgress = () => {
    const currentIndex = RANK_THRESHOLDS.findIndex(t => t.rank === player.rank);
    const currentMin = RANK_THRESHOLDS[currentIndex].min;
    const nextObj = RANK_THRESHOLDS[currentIndex + 1];
    if (!nextObj) return 100;
    const range = nextObj.min - currentMin;
    const currentPointsInRange = player.rankPoints - currentMin;
    return Math.min(100, (currentPointsInRange / range) * 100);
  };

  const getPointsToNextRank = () => {
    const currentIndex = RANK_THRESHOLDS.findIndex(t => t.rank === player.rank);
    const nextObj = RANK_THRESHOLDS[currentIndex + 1];
    if (!nextObj) return "MÁXIMO";
    return `${player.rankPoints} / ${nextObj.min} PTS`;
  };

  const getMissionIcon = (type: string) => {
    switch (type) {
      case "physical": return <Zap size={28} className="text-sky-400" />;
      case "hydration": return <Droplets size={28} className="text-blue-400" />;
      case "study": return <Book size={28} className="text-indigo-400" />;
      case "nutrition": return <Apple size={28} className="text-emerald-400" />;
      case "sleep": return <Moon size={28} className="text-slate-400" />;
      case "org": return <Layout size={28} className="text-amber-400" />;
      default: return <Clock size={28} className="text-sky-400" />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-rajdhani flex overflow-hidden">
      
      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-40 w-60 bg-slate-900 border-r border-sky-500/20 transition-transform duration-300 transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0 shadow-2xl`}>
        <div className="p-6 h-full flex flex-col">
          <div className="flex justify-between items-center mb-10">
            <h2 className="font-orbitron font-black text-sky-400 text-lg tracking-widest italic system-glow">SISTEMA</h2>
            <button onClick={() => setIsSidebarOpen(false)} className="md:hidden text-sky-400 p-1">
              <X size={20} />
            </button>
          </div>

          <nav className="flex-1 space-y-2">
            {[
              { id: 'daily', icon: <Clock size={16} />, label: 'Missão Diária' },
              { id: 'list', icon: <LayoutDashboard size={16} />, label: 'Meus Protocolos' },
              { id: 'create', icon: <PlusCircle size={16} />, label: 'Nova Diretriz' },
              { id: 'settings', icon: <UserCircle size={16} />, label: 'Interface' }
            ].map(item => (
              <button 
                key={item.id}
                onClick={() => { setActiveView(item.id as any); setIsSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 p-3 rounded-lg text-[10px] font-orbitron font-bold uppercase transition-all ${activeView === item.id ? 'bg-sky-500/10 text-sky-400 border-l-4 border-sky-400 shadow-[inset_10px_0_20px_rgba(14,165,233,0.05)]' : 'hover:bg-slate-800 text-slate-500'}`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            ))}
          </nav>

          <div className="mt-auto pt-6 border-t border-slate-800">
             <div className="bg-slate-950 p-3 rounded-xl border border-sky-500/10 shadow-inner">
                <div className="flex justify-between items-center mb-1.5">
                   <span className="text-[8px] font-orbitron font-black text-sky-600 uppercase tracking-widest">Reserva XP</span>
                   <span className="text-[8px] font-orbitron text-slate-500">{player.exp} / {player.expToNext}</span>
                </div>
                <div className="h-1 bg-slate-900 rounded-full overflow-hidden">
                   <div className="h-full bg-sky-500 transition-all duration-700 shadow-[0_0_8px_#0ea5e9]" style={{ width: `${(player.exp / player.expToNext) * 100}%` }}></div>
                </div>
             </div>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col w-full relative">
        
        {/* Header imersivo */}
        <header className="py-8 px-6 flex flex-col items-center justify-center bg-slate-950/80 backdrop-blur-xl border-b border-sky-500/10 relative overflow-hidden">
          <button onClick={() => setIsSidebarOpen(true)} className="md:hidden absolute left-6 top-1/2 -translate-y-1/2 text-sky-400">
            <Menu size={24} />
          </button>
          
          <div className="text-center z-10 animate-in fade-in zoom-in duration-700">
            <h1 className="text-2xl md:text-4xl font-orbitron font-black text-white uppercase tracking-[0.2em] system-glow mb-2">
              {player.name}
            </h1>
            
            <div className="flex flex-col items-center">
               <div className={`text-xl md:text-3xl font-orbitron font-black uppercase italic tracking-[0.1em] ${getRankColor(player.rank)} ${getRankGlowClass(player.rank)}`}>
                 Rank {player.rank}
               </div>

               {/* Progresso de Rank */}
               <div className="mt-3 w-48 md:w-72 flex flex-col items-center gap-1">
                  <div className="w-full h-1 bg-slate-900 rounded-full overflow-hidden border border-white/5 shadow-inner">
                    <div 
                      className={`h-full transition-all duration-1000 ease-out ${player.rank === Rank.S ? 'bg-amber-400 shadow-[0_0_10px_#fbbf24]' : 'bg-sky-500 shadow-[0_0_10px_#0ea5e9]'}`}
                      style={{ width: `${getRankProgress()}%` }}
                    ></div>
                  </div>
                  <span className="text-[8px] md:text-[9px] font-orbitron font-black text-slate-500 uppercase tracking-[0.3em]">
                    {getPointsToNextRank()}
                  </span>
               </div>

               {/* Nível XP */}
               <div className="mt-4 flex flex-col items-center">
                  <div className="text-[11px] md:text-xs text-sky-400 font-orbitron font-black uppercase tracking-[0.5em]">
                    Nível {player.level}
                  </div>
               </div>
            </div>
          </div>
          
          {/* Fundo decorativo */}
          <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none">
             <div className="w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-sky-500 via-transparent to-transparent"></div>
          </div>
        </header>

        {/* Dynamic Content */}
        <main className="flex-1 p-6 md:p-10 overflow-y-auto">
          <div className="max-w-2xl mx-auto pb-20">
            
            {activeView === 'daily' && dailyQuest && (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom duration-700">
                <div className="flex flex-col items-center text-center">
                  <h2 className="text-lg font-orbitron font-black text-white uppercase tracking-[0.3em] flex items-center gap-4">
                    <Dna className="text-sky-500 animate-pulse" size={24} />
                    DIRETRIZ DIÁRIA DO SISTEMA
                  </h2>
                  <div className={`mt-3 px-6 py-1.5 rounded-full text-[10px] font-orbitron font-black uppercase tracking-widest border-2 ${
                    dailyQuest.difficulty === 'Fácil' ? 'border-emerald-500/30 text-emerald-400 bg-emerald-500/5 shadow-[0_0_10px_rgba(16,185,129,0.1)]' :
                    dailyQuest.difficulty === 'Médio' ? 'border-sky-500/30 text-sky-400 bg-sky-500/5 shadow-[0_0_10px_rgba(14,165,233,0.1)]' :
                    'border-red-500/30 text-red-400 bg-red-500/5 animate-pulse shadow-[0_0_15px_rgba(239,68,68,0.2)]'
                  }`}>
                    Protocolo: {dailyQuest.difficulty}
                  </div>
                </div>

                <div className="system-gradient border-2 border-sky-500/20 p-12 rounded-[2.5rem] relative overflow-hidden shadow-[0_0_60px_rgba(0,0,0,0.6)] flex flex-col items-center">
                  <div className="mb-8 p-6 rounded-full bg-slate-950 border-2 border-sky-500/30 text-sky-400 shadow-[0_0_30px_rgba(14,165,233,0.25)] animate-in zoom-in duration-500">
                    {getMissionIcon(dailyQuest.type)}
                  </div>

                  <h3 className="text-4xl font-black text-white uppercase font-orbitron tracking-tighter text-center mb-6 leading-tight system-glow">
                    {dailyQuest.name}
                  </h3>
                  
                  <div className="flex flex-col items-center mb-12">
                    <span className="text-xs font-orbitron text-slate-500 uppercase tracking-widest italic mb-3 opacity-60">Alvo Requerido</span>
                    <div className="text-6xl font-orbitron font-black text-sky-500 flex items-baseline gap-3 shadow-sky-500/10">
                      {dailyQuest.displayTarget}
                    </div>
                  </div>

                  <button 
                    onClick={completeDailyQuest}
                    disabled={dailyQuest.completed}
                    className={`w-full max-w-sm py-6 rounded-2xl text-sm font-black uppercase font-orbitron tracking-[0.5em] transition-all border-2 shadow-2xl relative overflow-hidden group ${
                      dailyQuest.completed 
                      ? 'border-emerald-500/20 text-emerald-500/30 cursor-not-allowed bg-emerald-500/5' 
                      : 'border-sky-500 text-white bg-sky-950/60 hover:bg-sky-500 hover:text-slate-950 active:scale-95 shadow-sky-500/30'
                    }`}
                  >
                    {dailyQuest.completed ? '[ SINCRONIZADO ]' : '[ CONCLUÍDO ]'}
                    {!dailyQuest.completed && <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>}
                  </button>

                  {/* Detalhes estéticos */}
                  <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none scale-150">
                    <Clock size={150} />
                  </div>
                  <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-sky-500/10 rounded-full blur-[100px] pointer-events-none"></div>
                </div>

                <div className="p-6 bg-slate-900/40 border-l-4 border-amber-600 rounded-2xl shadow-lg backdrop-blur-sm">
                  <div className="flex items-start gap-4">
                     <div className="p-2 bg-amber-600/10 rounded-lg"><Coffee size={18} className="text-amber-500" /></div>
                     <p className="text-[11px] font-orbitron text-amber-500/90 font-bold uppercase tracking-[0.15em] leading-relaxed italic">
                      [LOG DO SISTEMA]: O crescimento é uma jornada constante. Negligenciar os protocolos diários resultará em penalidade de status.
                     </p>
                  </div>
                </div>
              </div>
            )}

            {activeView === 'list' && (
              <div className="space-y-6 animate-in fade-in slide-in-from-bottom duration-500">
                <div className="flex justify-between items-center border-b border-slate-900 pb-3">
                  <h2 className="text-xs font-orbitron font-black text-slate-500 uppercase tracking-widest flex items-center gap-3 italic">
                    <LayoutDashboard size={14} className="text-sky-500" /> Registros de Operação
                  </h2>
                </div>

                {quests.length === 0 ? (
                  <div className="text-center py-24 bg-slate-900/10 border border-dashed border-slate-800 rounded-[2rem]">
                    <p className="text-slate-700 font-orbitron text-xs uppercase tracking-[0.4em]">Sem diretrizes manuais ativas.</p>
                  </div>
                ) : (
                  <div className="grid gap-5">
                    {quests.map(q => (
                      <div key={q.id} className="system-gradient border border-sky-500/10 p-6 rounded-2xl relative overflow-hidden group hover:border-sky-500/40 transition-all shadow-2xl">
                        <div className="flex justify-between items-start mb-5">
                          <div>
                            <h3 className="text-lg font-bold text-white uppercase font-orbitron tracking-tight">{q.name}</h3>
                            <p className="text-[11px] text-slate-500 italic mt-2 opacity-80">{q.description || 'Sem descrição tática.'}</p>
                          </div>
                          <button onClick={() => deleteQuest(q.id)} className="text-slate-700 hover:text-red-500 transition-colors p-2 bg-slate-950/40 rounded-lg border border-white/5">
                            <Trash2 size={18} />
                          </button>
                        </div>
                        
                        <div className="space-y-3">
                          <div className="flex justify-between text-[11px] font-orbitron font-bold text-slate-500 uppercase tracking-widest">
                             <span>Sincronização</span>
                             <span>{Math.floor((q.current / q.target) * 100)}%</span>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="flex-1 h-2 bg-slate-950 rounded-full overflow-hidden border border-white/5 shadow-inner">
                              <div 
                                className={`h-full transition-all duration-1000 ${q.current >= q.target ? 'bg-emerald-400 shadow-[0_0_15px_#34d399]' : 'bg-sky-500 shadow-[0_0_15px_#0ea5e9]'}`}
                                style={{ width: `${(q.current / q.target) * 100}%` }}
                              ></div>
                            </div>
                            <span className={`font-orbitron font-black text-sm w-16 text-right ${q.current >= q.target ? 'text-emerald-400' : 'text-sky-500'}`}>
                              {q.current} / {q.target}
                            </span>
                          </div>
                        </div>

                        <div className="mt-6">
                          <button 
                            onClick={() => updateQuest(q.id, 1)}
                            disabled={q.current >= q.target}
                            className={`w-full py-4 rounded-xl text-[11px] font-black uppercase font-orbitron tracking-[0.3em] transition-all border ${q.current >= q.target ? 'border-emerald-500/10 text-emerald-500/20 bg-emerald-500/5' : 'border-sky-500/30 text-sky-400 hover:bg-sky-500/10 active:scale-[0.98]'}`}
                          >
                            {q.current >= q.target ? '[ PROTOCOLO FINALIZADO ]' : '[ EXECUTAR PASSO ]'}
                          </button>
                        </div>
                        
                        <div className={`absolute left-0 top-0 bottom-0 w-1.5 transition-all duration-1000 ${q.current >= q.target ? 'bg-emerald-500' : 'bg-sky-500'}`}></div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeView === 'create' && (
              <div className="animate-in fade-in slide-in-from-left duration-500">
                <h2 className="text-sm font-orbitron font-black text-white uppercase mb-8 flex items-center gap-3">
                   <PlusCircle size={20} className="text-sky-500" /> Abrir Novo Protocolo
                </h2>
                
                <div className="space-y-6 bg-slate-900/30 p-10 rounded-[2.5rem] border border-sky-500/10 shadow-2xl backdrop-blur-md">
                  <div className="space-y-2">
                    <label className="text-[11px] font-orbitron font-black text-sky-500 uppercase tracking-widest ml-1">Identificador da Missão</label>
                    <input 
                      type="text" 
                      placeholder="EX: TREINO DE SOMBRAS"
                      value={newQuest.name}
                      onChange={e => setNewQuest({...newQuest, name: e.target.value})}
                      className="w-full bg-slate-950/80 border-2 border-slate-800 rounded-2xl p-5 text-white font-orbitron text-sm focus:border-sky-500 outline-none transition-all placeholder:text-slate-900 shadow-inner"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[11px] font-orbitron font-black text-sky-500 uppercase tracking-widest ml-1">Meta Quantitativa</label>
                    <input 
                      type="number" 
                      min="1"
                      value={newQuest.target}
                      onChange={e => setNewQuest({...newQuest, target: parseInt(e.target.value) || 1})}
                      className="w-full bg-slate-950/80 border-2 border-slate-800 rounded-2xl p-5 text-white font-orbitron text-sm focus:border-sky-500 outline-none transition-all shadow-inner"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[11px] font-orbitron font-black text-sky-500 uppercase tracking-widest ml-1">Especificações Técnicas</label>
                    <textarea 
                      placeholder="Descreva o procedimento operacional..."
                      value={newQuest.description}
                      onChange={e => setNewQuest({...newQuest, description: e.target.value})}
                      className="w-full bg-slate-950/80 border-2 border-slate-800 rounded-2xl p-5 text-white font-orbitron text-sm focus:border-sky-500 outline-none transition-all h-32 resize-none placeholder:text-slate-900 shadow-inner"
                    />
                  </div>
                  <button 
                    onClick={handleCreateQuest}
                    className="w-full py-6 bg-sky-900 hover:bg-sky-600 text-white font-orbitron font-black uppercase tracking-[0.5em] transition-all rounded-2xl text-xs active:scale-[0.98] shadow-[0_15px_30px_rgba(12,74,110,0.3)] mt-4 border border-sky-500/30"
                  >
                    ATIVAR DIRETRIZ
                  </button>
                </div>
              </div>
            )}

            {activeView === 'settings' && (
              <div className="animate-in fade-in zoom-in duration-500">
                <h2 className="text-sm font-orbitron font-black text-white uppercase mb-8 flex items-center gap-3">
                   <UserCircle size={20} className="text-sky-500" /> Interface do Jogador
                </h2>
                
                <div className="bg-slate-900/30 p-10 rounded-[2.5rem] border border-sky-500/10 mb-8 backdrop-blur-md shadow-2xl">
                  <div className="mb-10">
                    <label className="text-[11px] font-orbitron font-black text-sky-500 uppercase tracking-widest mb-4 block ml-1">Codinome Designado</label>
                    <div className="flex gap-4">
                      <input 
                        type="text" 
                        placeholder={player.name}
                        value={newName}
                        onChange={e => setNewName(e.target.value)}
                        className="flex-1 bg-slate-950/80 border-2 border-slate-800 rounded-2xl p-5 text-white font-orbitron text-sm focus:border-sky-500 outline-none transition-all shadow-inner"
                      />
                      <button 
                        onClick={changeName}
                        className="px-8 bg-sky-800 text-white font-orbitron font-black uppercase text-xs rounded-2xl hover:bg-sky-500 transition-all shadow-xl shadow-sky-500/10"
                      >
                        SINC
                      </button>
                    </div>
                  </div>
                  
                  <div className="pt-8 border-t border-slate-800 flex items-center justify-between">
                    <p className="text-slate-600 font-bold font-orbitron uppercase text-[10px] tracking-[0.2em]">Deletar todos os logs de dados</p>
                    <button 
                      onClick={() => { if(confirm("ALERTA: Isso aniquilará permanentemente seu nível e rank. Deseja prosseguir?")) { localStorage.clear(); window.location.reload(); } }}
                      className="px-6 py-3 border border-red-900/40 text-red-800 hover:bg-red-500/10 font-black uppercase text-[10px] rounded-xl font-orbitron transition-all"
                    >
                      RESETAR
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-6">
                   <div className="p-8 border-2 border-sky-500/10 rounded-3xl bg-sky-500/5 shadow-inner group hover:border-sky-500/30 transition-all">
                      <p className="text-[9px] font-orbitron font-bold text-slate-500 uppercase mb-3 tracking-[0.4em] opacity-60">Prestígio de Rank</p>
                      <p className="text-3xl font-orbitron font-black text-sky-400 system-glow">{player.rankPoints} <span className="text-sm opacity-20">PTS</span></p>
                   </div>
                   <div className="p-8 border-2 border-sky-500/10 rounded-3xl bg-sky-500/5 shadow-inner group hover:border-sky-500/30 transition-all">
                      <p className="text-[9px] font-orbitron font-bold text-slate-500 uppercase mb-3 tracking-[0.4em] opacity-60">Gold Reservado</p>
                      <p className="text-3xl font-orbitron font-black text-amber-500 drop-shadow-[0_0_10px_rgba(245,158,11,0.3)]">{player.gold} <span className="text-sm opacity-20">G</span></p>
                   </div>
                </div>
              </div>
            )}

          </div>
        </main>
      </div>

      {/* Modal Integration */}
      {modal.isOpen && (
        <SystemModal 
          title={modal.title} 
          message={modal.message} 
          type={modal.type}
          onClose={() => setModal(prev => ({ ...prev, isOpen: false }))} 
        />
      )}
    </div>
  );
};

export default App;
