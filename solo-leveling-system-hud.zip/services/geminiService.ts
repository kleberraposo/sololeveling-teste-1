
import { GoogleGenAI } from "@google/genai";

// Initialize the GoogleGenAI client with the API key from environment variables.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getSystemMessage = async (context: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: context,
      config: {
        systemInstruction: `Você é "O Sistema" do anime Solo Leveling. Suas respostas devem ser curtas, frias, autoritárias e apresentadas como mensagens de sistema HUD. Use termos como [ALERTA], [MISSÃO], [RECOMPENSA] ou [NÍVEL AUMENTOU]. Sua linguagem é focada em status, janelas flutuantes e diretrizes diretas ao Jogador.`,
        temperature: 0.7,
      },
    });
    return response.text || "O Sistema encontrou um erro desconhecido.";
  } catch (error) {
    console.error("Erro ao contatar o Sistema:", error);
    return "[ALERTA] Falha na conexão com o Servidor Central.";
  }
};

export const getRewardMessage = async (playerLevel: number) => {
  const prompt = `Gere uma mensagem de recompensa de sistema para um jogador de nível ${playerLevel} que acabou de completar uma quest diária.`;
  return getSystemMessage(prompt);
};
