
export enum Rank {
  E = 'E',
  D = 'D',
  C = 'C',
  B = 'B',
  A = 'A',
  S = 'S'
}

export enum Job {
  NONE = 'Nenhum',
  MAGE = 'Mago',
  ASSASSIN = 'Assassino',
  WARRIOR = 'Guerreiro',
  NECROMANCER = 'Monarca das Sombras'
}

export enum Title {
  NEWBIE = 'O Recém-Desperto',
  SLAUGHTERER = 'O Carniceiro',
  MONARCH = 'Monarca das Sombras'
}

export interface Stats {
  strength: number;
  vitality: number;
  agility: number;
  intelligence: number;
  perception: number;
}

export interface Quest {
  id: string;
  name: string;
  target: number;
  current: number;
  description: string;
}

export interface Player {
  name: string;
  level: number;
  rank: Rank;
  rankPoints: number;
  job: Job;
  title: Title;
  hp: { current: number; max: number };
  mp: { current: number; max: number };
  fatigue: number;
  stats: Stats;
  statPoints: number;
  gold: number;
  exp: number;
  expToNext: number;
}
